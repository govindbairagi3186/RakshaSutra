// RakshaSutra PWA registration
(function () {
  if (!("serviceWorker" in navigator)) {
    return;
  }

  window.addEventListener("load", function () {
    navigator.serviceWorker
      .register("./service-worker.js", { scope: "./" })
      .then(function (registration) {
        console.log("RakshaSutra service worker registered:", registration.scope);
      })
      .catch(function (error) {
        console.error("RakshaSutra service worker registration failed:", error);
      });
  });
})();
